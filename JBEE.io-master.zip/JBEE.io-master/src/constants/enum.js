export const CATEGORY_TYPE = {
  ALL: 'All',
}

export const THEME = {
  LIGHT: 'light',
  DARK: 'dark',
}
