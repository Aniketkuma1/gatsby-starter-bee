export const SCROLL_Y = 'y'
