export const KOREAN = 'ko'
export const ENGLISH = 'en'
